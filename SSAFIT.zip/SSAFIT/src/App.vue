<script setup>
import HomePage from '@/views/HomePage.vue';
</script>

<template>
  <div>
    <HomePage />
  </div>
</template>

<style scoped></style>
