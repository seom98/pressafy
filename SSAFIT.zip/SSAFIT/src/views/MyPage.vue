<template>
    <div>
        <h2>마이페이지임.</h2>
    </div>
</template>

<script setup>

</script>

<style scoped></style>